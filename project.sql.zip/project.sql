-- phpMyAdmin SQL Dump
-- version 2.9.0.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 03, 2016 at 09:47 AM
-- Server version: 5.0.27
-- PHP Version: 5.2.0
-- 
-- Database: `project`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `customer`
-- 

CREATE TABLE `customer` (
  `Cust_ID` int(30) NOT NULL auto_increment,
  `FName` varchar(30) NOT NULL,
  `MName` varchar(30) NOT NULL,
  `LName` varchar(30) NOT NULL,
  `BMonth` varchar(10) NOT NULL,
  `BDay` varchar(10) NOT NULL,
  `BYear` varchar(10) NOT NULL,
  `Street` varchar(20) NOT NULL,
  `Barangay` varchar(20) NOT NULL,
  `City` varchar(20) NOT NULL,
  `Prov` varchar(20) NOT NULL,
  `Gender` varchar(30) NOT NULL,
  `Contact` varchar(30) NOT NULL,
  PRIMARY KEY  (`Cust_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `customer`
-- 

INSERT INTO `customer` (`Cust_ID`, `FName`, `MName`, `LName`, `BMonth`, `BDay`, `BYear`, `Street`, `Barangay`, `City`, `Prov`, `Gender`, `Contact`) VALUES 
(1, 'Justine', 'Tulao', 'Encarnacion', 'October', '22', '1997', '123', 'Sta.Isabel', 'Kawit', 'Cavite', 'Male', '09066102230'),
(2, 'Shadow', 'Fiend', 'Never', 'March', '26', '1929', '512', 'Tabon', 'Kawit', 'Cavite', 'Male', 'Kawit,Cavite'),
(3, 'Luna', 'Moon', 'Fang', 'July', '23', '1969', '75', 'Awa', 'Ermita ', 'Manila', 'Female', '09234152728'),
(4, 'Riki', 'Stealth', 'Assassin', 'August', '26', '1998', '612', 'Manggahan', 'Kawit', 'Cavite', 'Male', '09246122324'),
(5, 'Magina', 'Anti', 'Mage', 'March', '13', '1972', '345', 'Asin', 'Malate', 'Manila', 'Male', '09410922310'),
(6, 'Akasha', 'Queen', 'Pain', 'September', '8', '1988', '41', 'Saw', 'Kalaw ', 'Manila', 'Male', '09326124210'),
(7, 'Slardar', 'Slithereen ', 'Guard', 'March', '27', '1940', '41', 'Mura', 'Paco', 'Manila', 'Male', '09671939131'),
(8, 'Jasda', 'Mara', 'Mubas', 'May', '28', '1926', '712', 'Baser', 'Noveleta', 'Cavite', 'Female', '09234141209'),
(9, 'Bangaw', 'Hidalgo', 'Ocbina', 'September', '29', '1997', '214', 'Pag-asa', 'Imus', 'Cavite', 'Male', '09234114190'),
(10, 'Blamo', 'Bravo', 'Johnny', 'April', '22', '1944', '415', 'Pogi', 'Cavite', 'Cavite', 'Male', '09123141124'),
(11, 'Dassa', 'Marask', 'Breada', 'October', '13', '1981', '141', 'Ilaw', 'Davao', 'Davao', 'Female', '09234150209'),
(12, 'Alvin', 'asda', 'Tria', 'March', '20', '1981', '1232', 'Tala', 'Pogi', 'Caloocan', 'Male', '09066102230'),
(13, 'Kimi', 'No ', 'Nawa', 'January', '1', '2007', '12', 'Sta.Isabel', 'Kawit', 'Cavite', 'Male', '09066102230'),
(14, 'Japeth', 'Talo', 'Aguilar', 'January', '22', '1926', '123', 'Kangkong ', 'Noveleta', 'Cavite', 'Male', '09023123150'),
(15, 'Justine', 'Tulao', 'Encarnacion', 'October', '22', '1997', '123', 'Sta.Isabel', 'Kawit', 'Cavite', 'Male', '09066102230'),
(16, 'as', 'a', 'sdfd', 'January', '21', '1923', 'ad', 'saf', 'qer', 'sf', 'Female', '0934567');

-- --------------------------------------------------------

-- 
-- Table structure for table `customerarch`
-- 

CREATE TABLE `customerarch` (
  `Cust_Id` varchar(30) NOT NULL,
  `FName` varchar(30) NOT NULL,
  `MName` varchar(30) NOT NULL,
  `LName` varchar(30) NOT NULL,
  `BMonth` varchar(10) NOT NULL,
  `BDay` varchar(10) NOT NULL,
  `BYear` varchar(10) NOT NULL,
  `Street` varchar(20) NOT NULL,
  `Barangay` varchar(20) NOT NULL,
  `City` varchar(20) NOT NULL,
  `Prov` varchar(20) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Contact` varchar(20) NOT NULL,
  PRIMARY KEY  (`Cust_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `customerarch`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `login`
-- 

CREATE TABLE `login` (
  `user` varchar(30) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `position` varchar(10) NOT NULL,
  PRIMARY KEY  (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `login`
-- 

INSERT INTO `login` (`user`, `pass`, `position`) VALUES 
('admin', '12345', 'Admin'),
('cashier', '12345', 'Cashier');

-- --------------------------------------------------------

-- 
-- Table structure for table `order`
-- 

CREATE TABLE `order` (
  `Order_ID` int(30) NOT NULL auto_increment,
  `Cust_ID` int(30) NOT NULL,
  `Prod_ID` int(30) NOT NULL,
  `Date` varchar(30) NOT NULL,
  `Quantity` int(10) NOT NULL,
  `Price` double NOT NULL,
  PRIMARY KEY  (`Order_ID`),
  KEY `Cust_ID` (`Cust_ID`),
  KEY `Prod_ID` (`Prod_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

-- 
-- Dumping data for table `order`
-- 

INSERT INTO `order` (`Order_ID`, `Cust_ID`, `Prod_ID`, `Date`, `Quantity`, `Price`) VALUES 
(1, 2, 10, '9/10/2016', 2, 12000),
(2, 4, 15, '9/14/2016', 12, 42000),
(3, 9, 3, '10/1/2016', 4, 24000),
(4, 7, 6, '10/18/2016', 12, 18000),
(5, 3, 4, '11/8/2016', 8, 72000),
(6, 1, 2, '11/24/2016', 12, 78000),
(7, 4, 2, '9/10/2016', 12, 78000),
(8, 3, 6, '9/10/2016', 100, 150000),
(9, 12, 19, '9/10/2016', 100, 900000),
(10, 12, 19, '9/10/2016', 901, 8109000),
(11, 7, 19, '10/7/2016', 12, 108000),
(12, 12, 19, '10/7/2016', 90, 810000),
(13, 10, 19, '10/7/2016', 88, 810000),
(14, 12, 24, '10/7/2016', 12, 30000),
(15, 9, 6, '10/7/2016', 100, 300000),
(16, 10, 6, '10/7/2016', 100, 300000),
(17, 5, 2, '10/21/2016', 12, 84500),
(18, 2, 2, '10/21/2016', 1, 936000);

-- --------------------------------------------------------

-- 
-- Table structure for table `orderarch`
-- 

CREATE TABLE `orderarch` (
  `Order_ID` int(30) NOT NULL,
  `Cust_ID` int(30) NOT NULL,
  `Prod_ID` int(30) NOT NULL,
  `Date` varchar(30) NOT NULL,
  `Quantity` int(30) NOT NULL,
  `Price` double NOT NULL,
  PRIMARY KEY  (`Order_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `orderarch`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `orderpaid`
-- 

CREATE TABLE `orderpaid` (
  `Order_ID` int(30) NOT NULL,
  `Cust_ID` int(30) NOT NULL,
  `Prod_ID` int(30) NOT NULL,
  `Date` varchar(30) NOT NULL,
  `Quantity` int(30) NOT NULL,
  `Price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `orderpaid`
-- 

INSERT INTO `orderpaid` (`Order_ID`, `Cust_ID`, `Prod_ID`, `Date`, `Quantity`, `Price`) VALUES 
(1, 2, 10, '9/10/2016', 2, 12000),
(4, 7, 6, '10/18/2016', 12, 18000),
(6, 1, 2, '11/24/2016', 12, 78000),
(1, 2, 10, '9/10/2016', 2, 12000);

-- --------------------------------------------------------

-- 
-- Table structure for table `prodarch`
-- 

CREATE TABLE `prodarch` (
  `Prod_ID` varchar(30) NOT NULL,
  `Prod_Name` varchar(30) NOT NULL,
  `Price` float NOT NULL,
  `Prod_Brand` varchar(30) NOT NULL,
  `Quantity` int(30) NOT NULL,
  PRIMARY KEY  (`Prod_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `prodarch`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `product`
-- 

CREATE TABLE `product` (
  `Prod_ID` int(30) NOT NULL auto_increment,
  `Prod_Name` varchar(30) NOT NULL,
  `Price` float NOT NULL,
  `Prod_Brand` varchar(30) NOT NULL,
  `Quantity` int(30) NOT NULL,
  PRIMARY KEY  (`Prod_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

-- 
-- Dumping data for table `product`
-- 

INSERT INTO `product` (`Prod_ID`, `Prod_Name`, `Price`, `Prod_Brand`, `Quantity`) VALUES 
(1, 'Oil Cooler', 3000, 'Isuzu', 1100),
(2, 'Propeler', 6500, 'Fuzo', 0),
(3, 'Brake Drum', 6000, 'Isuzu', 1000),
(4, 'Gear Box', 9000, 'Nissan', 1008),
(5, 'Accelshop', 3500, 'Hino', 1000),
(6, 'Clutch Booster', 1500, 'Fuzo', 0),
(7, 'Steering Pump', 5000, 'Isuzu', 1000),
(8, 'Crankshop', 55000, 'Hino', 1000),
(9, 'Pressure Plate', 4500, 'Isuzu', 1000),
(10, 'Flywheel', 6000, 'Hino', 1000),
(11, 'Piston', 3000, 'Fuzo', 1000),
(12, 'Liner', 2500, 'Hino', 1000),
(13, 'DIfferential', 33000, 'Fuzo', 1000),
(14, 'Transmission', 28000, 'Hino', 1000),
(15, 'Air Cleaner', 3500, 'Nissan', 988),
(16, 'Left Spring', 7500, 'Isuzu', 1000),
(17, 'Main Drive ', 7500, 'Isuzu', 1000),
(18, 'Starter ', 10000, 'Isuzu', 1000),
(19, 'Alternator', 9000, 'Fuzo', 0),
(20, 'Air Compressor', 6500, 'Isuzu', 1000),
(21, 'Oil Pump', 6500, 'Hino', 1000),
(22, 'Brake Shoe', 2500, 'Fuzo', 1000),
(23, 'Bell Housing', 5000, 'Fuzo', 1000),
(24, 'Clutch Disk', 2500, 'Fuzo', 988),
(25, 'Hub', 3500, 'Isuzu', 1000),
(26, 'jt', 1092, 'Fuzo', 1000),
(27, 'aewq', 133, 'Fuzo', 0);

-- 
-- Constraints for dumped tables
-- 

-- 
-- Constraints for table `order`
-- 
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`Cust_ID`) REFERENCES `customer` (`Cust_ID`),
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`Cust_ID`) REFERENCES `customer` (`Cust_ID`),  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`Prod_ID`) REFERENCES `product` (`Prod_ID`);
